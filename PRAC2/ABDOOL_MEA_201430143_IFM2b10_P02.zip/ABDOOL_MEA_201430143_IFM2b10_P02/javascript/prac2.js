
var name;// store customer name
var  surname;// store customer surname
var  duration ;// store durataion
var count=0;//count keep  track  of the checked
var upfront;// yes or no
  var message //errror message above button ;

  var inputElems// store input tag  elemetns ;

function  validateCheckboxes()
{


 inputElems =document.getElementsByTagName("input");//we have all our inputs

 for (var i=0; i<inputElems.length; i++){
if (inputElems[i].getAttribute("type") == "checkbox" )//we found our checkedboxss
{
  if(inputElems[i].checked== true)// found alluse that code to fin those that  are cheked
  {



    count++;//we increase our counter
  }
  else {
    count=0;// if its not cheked set our counter back to 0
  }
  if(count>2)
  {
    return inputElems[i].checked=false;//next object will  be set to false
  }

}

}



}




function submitForm()
{
 var input =document.getElementsByTagName("input");
   message  =  document.getElementById('error');
  var Totalcost=0;// store total  cost
  var discount;//  discount if applicable
    var inputElems =document.getElementsByTagName("input");//we have all our inputs
    upfront=  document.getElementById('upfront').checked;  //  store if we checked upfront or not
var sport = document.getElementById("sport");
var series = document.getElementById("series");
var movie=document.getElementById("movie");
  try {

    duration= document.getElementById('duration').value;//Stored our duration
    name= document.getElementById('name').value;//store our name value
    surname= document.getElementById('surname').value;// we storing whatever suranme is entered
    if( surname == ""|name=="")
    {
      throw " surname and name are required";
    }
    if(!isNaN(surname))
    {
      throw " surname is not a number ";
    }

      if(!isNaN(name))
      {
              throw " Name is not a number ";
      }
      if(count<0)
      {
        throw "One package must be selcted";
      }

      if (isNaN(duration))
      {
        throw " duration is number ";
      }
      if(duration<0)
      {
        throw " invalid duration";
      }else if (duration>24) {
          throw " invalid duration";
      }

      document.write( "<h1>Summary </h1>");
        document.write( "Name:"+name+"<br>");
          document.write( "surname:"+surname+"<br>");

          if(sport.checked)
          {
            //display your info -- get it? okay  ....
            document.write("package: "+sport.id+"<br>");
          }
          if(movie.checked)
          {
            document.write("package: "+movie.id+"<br>");
          }
          if(series.checked)
          {
            document.write("package: "+series.id+"<br>");
          }





    
        document.write( "duration:"+duration+"<br>");
        Totalcost=99*duration;
        console.log(upfront);
      if(upfront==true)
      {
  if (duration >=6 && duration<=12)
  {
   Totalcost =  parseFloat(Math.round(Totalcost * 100) / 100).toFixed(2);
    discount= 0.1*Totalcost;
    discount =  parseFloat(Math.round(discount * 100) / 100).toFixed(2);
        document.write( "You  have a discount of R"+discount+"<br>");
        Totalcost=Totalcost-discount;
      document.write( "Totalcost:R"+Totalcost+"<br>");
  }
  else if (duration>12)
  {
    Totalcost =  parseFloat(Math.round(Totalcost * 100) / 100).toFixed(2);
     discount= 0.2*Totalcost;
     discount =  parseFloat(Math.round(discount * 100) / 100).toFixed(2);
         document.write( "You  have a discount of R"+discount+"<br>");
         Totalcost=Totalcost-discount;
       document.write( "Totalcost:R"+Totalcost+"<br>");

  }




  }
  else {
    document.write( "Totalcost:R"+Totalcost+"<br>");
  }














  } catch (err) {
    message.innerHTML= "Error possible cause :"+err
  }
}
//  we going to  make sure our message is printed above button
