﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {   
            
             
            String product_id = Request.QueryString["id"];

            string connection_string = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connection_string))
            {
                SqlCommand cmd = new SqlCommand("Select * from [dbo].[product] where ProductID=@product_id", con);
                SqlParameter id = new SqlParameter();
                id.ParameterName = "@product_id";
                id.Value = product_id;
                cmd.Parameters.Add(id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        lbldes.Text += "<p>" + reader["FullDescription"] + "</p>";
                    }
                }
            }
        }

    }
}