﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class edit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["ID"]==null)
            {
                Response.Redirect("Login.aspx");
            }
             
            if(!IsPostBack)
            {
                String product_id = Request.QueryString["id"];

                string connection_string = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(connection_string))
                {
                    SqlCommand cmd = new SqlCommand("Select * from [dbo].[product] where ProductID=@product_id", con);
                    SqlParameter id = new SqlParameter();
                    id.ParameterName = "@product_id";
                    id.Value = product_id;
                    cmd.Parameters.Add(id);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            // type.InnerHtml += reader["Type"].ToString()+"<br>" ;
                            txtname.Text = reader["Name"].ToString();
                            txtimage.Text = reader["ImageLocation"].ToString();
                            txtnum.Text = reader["NumItems"].ToString();
                            txttype.Text = reader["Type"].ToString();

                            txtshort.Text = reader["ShortDescription"].ToString();
                            txtlong.Text = reader["FullDescription"].ToString();

                        }

                    }
                    con.Close();
                }

            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          
           
int numitem = Convert.ToInt32(txtnum.Text);
             
             String product_id = Request.QueryString["id"];
            int pid = Convert.ToInt32(product_id);
            string connection_string = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connection_string))
            {

                SqlCommand cmd = new SqlCommand("Update [dbo].[product]  set Name=@name,ImageLocation=@image,NumItems=@num,Type=@type,ShortDescription=@short,FullDescription=@long where ProductID=@product_id",con);
            
                
                 
                SqlParameter n = new SqlParameter();
                n.ParameterName = "@name";
                n.Value = txtname.Text;
                cmd.Parameters.Add(n);
                SqlParameter t = new SqlParameter();
                t.ParameterName = "@type";
                t.Value = txttype.Text;
                cmd.Parameters.Add(t);
                SqlParameter num = new SqlParameter();
                num.ParameterName = "@num";
                num.Value = txtnum.Text;
                cmd.Parameters.Add(num);
                SqlParameter s = new SqlParameter();
                s.ParameterName = "@short";
                s.Value = txtshort.Text;
                cmd.Parameters.Add(s);
                SqlParameter l = new SqlParameter();
                l.ParameterName = "@long";
                l.Value = txtlong.Text;
                cmd.Parameters.Add(l);
                SqlParameter i = new SqlParameter();
                i.ParameterName = "@image";
                i.Value =txtimage.Text;
                cmd.Parameters.Add(i);
              
                SqlParameter id = new SqlParameter();
                id.ParameterName = "@product_id";
                id.Value = pid;
                cmd.Parameters.Add(id);

                con.Open();
                cmd.ExecuteNonQuery();
                Response.Redirect("home.aspx");

            }
        }
    }

        
    }
