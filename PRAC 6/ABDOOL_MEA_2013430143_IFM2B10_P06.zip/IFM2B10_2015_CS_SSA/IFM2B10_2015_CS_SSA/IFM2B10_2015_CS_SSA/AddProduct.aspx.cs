﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] == null)
            {
                Response.Redirect("home.aspx");
            }
        }

        protected void btnvalidate_Click(object sender, EventArgs e)
        {

            
           
            string connection_string = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connection_string))
            {
                String img = txtimage.Text;

                

                SqlCommand cmd = new SqlCommand("insert into  Product(Name,Type,NumItems,ShortDescription,FullDescription,ImageLocation) values(@name,@type,@num,@short,@long,@image)", con);
                SqlParameter n = new SqlParameter();
                n.ParameterName = "@name";
                n.Value = txtname.Text;
                cmd.Parameters.Add(n);
                SqlParameter t = new SqlParameter();
                t.ParameterName = "@type";
                t.Value = txttype.Text;
                cmd.Parameters.Add(t);
                SqlParameter num = new SqlParameter();
                num.ParameterName = "@num";
                num.Value = txtnum.Text;
                cmd.Parameters.Add(num);
                SqlParameter s = new SqlParameter();
                s.ParameterName = "@short";
                s.Value = txtshort.Text;
                cmd.Parameters.Add(s);
                SqlParameter l = new SqlParameter();
                l.ParameterName = "@long";
                l.Value = txtlong.Text;
                cmd.Parameters.Add(l);
                SqlParameter i = new SqlParameter();
                i.ParameterName = "@image";
               i.Value = img;
                cmd.Parameters.Add(i);




                con.Open();
                cmd.ExecuteNonQuery();



                    }

                }

            }
        }


    
