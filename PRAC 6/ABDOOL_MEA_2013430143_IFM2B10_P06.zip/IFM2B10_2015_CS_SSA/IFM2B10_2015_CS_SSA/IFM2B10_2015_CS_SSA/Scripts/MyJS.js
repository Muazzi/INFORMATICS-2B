﻿
function WriteTime() {
   
    document.getElementById("timeDiv").innerHTML = new Date();
}