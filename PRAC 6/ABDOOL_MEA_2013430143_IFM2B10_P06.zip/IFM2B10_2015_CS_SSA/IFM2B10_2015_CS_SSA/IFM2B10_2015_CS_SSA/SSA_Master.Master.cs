﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class SSA_Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["ID"] != null)
            {
                HyperLink a = (HyperLink)FindControl("logout");
                a.Visible = true;
                HyperLink b = (HyperLink)FindControl("HyperLink3");
                b.Visible = false;
                Label lbl = (Label)FindControl("lbluser");
                lbl.Text = "Welcome user!";

            }
        }
    }
}