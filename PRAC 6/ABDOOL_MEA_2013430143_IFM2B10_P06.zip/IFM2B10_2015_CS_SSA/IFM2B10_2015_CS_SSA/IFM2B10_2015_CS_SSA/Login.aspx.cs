﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace IFM2B10_2015_CS_SSA
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            String username = txtusername.Text;
            string password = txtpass.Text;
            SqlDataReader reader;
            password = Secrecy.HashPassword(password);
            //  tester(username, password); 
            string connection_string = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connection_string))
            {




                SqlCommand cmd = new SqlCommand("select UserId, Username,Password from [dbo].[User] where Username=@username and Password=@password", con);
                SqlParameter user = new SqlParameter();
                user.ParameterName = "@username";
                user.Value = username;
                cmd.Parameters.Add(user);
                SqlParameter pass = new SqlParameter();
                pass.ParameterName = "@password";
                pass.Value = password;
                cmd.Parameters.Add(pass);
                con.Open();
                reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);



                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //count++;
                        String p = reader["Password"].ToString();
                        String u = reader["Username"].ToString();
                        if (p.Equals(password)&& u.Equals(username))
                        {
                            Session["ID"] = reader["UserId"];


                            Response.Redirect("products.aspx");

                        }
                    }

                }




            }



        }



    }





}

