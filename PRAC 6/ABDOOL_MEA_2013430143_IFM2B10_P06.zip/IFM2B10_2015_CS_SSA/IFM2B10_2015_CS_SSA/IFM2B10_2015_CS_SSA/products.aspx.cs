﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace IFM2B10_2015_CS_SSA
{
    public partial class products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        { 
            if(Session["ID"]!=null)
            {
               
                Add.Visible = true;
            }
           
            string connection_string = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connection_string))
            {
                SqlCommand cmd = new SqlCommand("Select * from [dbo].[product]", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                    

                    
                        lbltext.Text += "<h2>" + reader["Name"] + "</h2>";
                        lbltext.Text += "<img src="+"'App_Media/"+ reader["ImageLocation"].ToString()+"'/>";
                        lbltext.Text += "<table>";
                        lbltext.Text += "<tr><td><b>Type:</b></td><td>" + reader["Type"].ToString() + "</td></tr>";
                        lbltext.Text += "<tr><td><b>Stock:</b></td><td>" + reader["NumItems"].ToString() + "</td></tr>";
                        lbltext.Text += "<tr><td><b>Short description:</b></td><td>" + reader["ShortDescription"].ToString() + "</td></tr>";
                        lbltext.Text += "<tr><td><b>Long description</b></td><td><a href='product.aspx?id="+reader["ProductID"].ToString() + "'>link</a></td></tr>";
                        lbltext.Text += "<tr><td><b>Edit</b></td><td><a href='edit.aspx?id=" + reader["ProductID"].ToString() + "'>link</a></td></tr>";
                        lbltext.Text += "</table>";
                    }


                }

            }
        }
    }
}